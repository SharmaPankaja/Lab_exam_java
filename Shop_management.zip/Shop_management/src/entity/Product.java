package entity;

public class Product {
	private static int id = 0;
	private int pid;
	private String pName;
	private double price;
	private int quantity;

	public Product(String pName, double price, int quantity) {
		super();
		this.pid = ++id;
		this.pName = pName;
		this.price = price;
		this.quantity = quantity;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pName=" + pName + ", price=" + price + ", quantity=" + quantity + "]";
	}

}
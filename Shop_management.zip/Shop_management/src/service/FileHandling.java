package service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import entity.Customer;
import entity.Product;

public class FileHandling {
	Shop shop;
	ArrayList<Shop> fileHandling;
	String LogFile = "D:\\Nikita\\ShopManagement.txt";

	public FileHandling() {
		fileHandling = new ArrayList<>();
	}

	void logshowDetails(String message) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(LogFile));
		writer.write(message);
		writer.newLine();
		writer.close();
	}
public ArrayList<Shop> book(int pid,int cid) throws Exception
{
	Product p=new Product(pid);
	Customer c=new 
	
}

}
